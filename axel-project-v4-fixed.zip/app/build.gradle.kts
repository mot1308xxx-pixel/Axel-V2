plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{
 namespace="com.axel.app";compileSdk=34
 defaultConfig{applicationId="com.axel.app";minSdk=26;targetSdk=34;versionCode=5;versionName="4.0"}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}
}
dependencies{implementation("androidx.core:core-ktx:1.13.1");implementation("androidx.webkit:webkit:1.11.0");implementation("com.squareup.okhttp3:okhttp:4.12.0")}
