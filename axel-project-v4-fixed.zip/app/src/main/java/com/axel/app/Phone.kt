package com.axel.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

object Phone {
    private val tr = mapOf('а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "e", 'ж' to "zh", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "ts", 'ч' to "ch", 'ш' to "sh", 'щ' to "sch", 'ъ' to "", 'ы' to "y", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya")
    private val alias = mapOf(
        "ютуб" to "youtube", "ютьюб" to "youtube", "ватсап" to "whatsapp", "вотсап" to "whatsapp", "хром" to "chrome",
        "телеграм" to "telegram", "телега" to "telegram", "вк" to "vk", "вконтакте" to "vk", "гугл" to "google",
        "камера" to "camera", "галерея" to "gallery", "фото" to "photos", "настройки" to "settings",
        "калькулятор" to "calculator", "часы" to "clock", "календарь" to "calendar", "карты" to "maps",
        "почта" to "gmail", "браузер" to "chrome", "плей маркет" to "play store", "тикток" to "tiktok",
        "инстаграм" to "instagram", "дискорд" to "discord", "твич" to "twitch", "стим" to "steam",
        "телефон" to "phone", "сообщения" to "messages", "спотифай" to "spotify", "нетфликс" to "netflix",
        "майнкрафт" to "minecraft", "роблокс" to "roblox", "браул старс" to "brawl stars", "бравл старс" to "brawl stars",
        "бравл" to "brawl stars", "браво старс" to "brawl stars", "яндекс" to "yandex", "сбер" to "sber",
        "едгар" to "edgar", "эдгар" to "edgar"
    )

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private fun lat(s: String) = norm(s).map { tr[it] ?: it.toString() }.joinToString("")

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + cost)
                prev = t
            }
        }
        return d[b.length]
    }

    fun start(c: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val host: Context = AlterAccessibilityService.instance ?: c
        host.startActivity(i)
        true
    } catch (e: Exception) { false }

    fun findApp(c: Context, name: String): String? {
        val q0 = alias[name.lowercase().trim()] ?: name
        val q1 = norm(q0)
        val q2 = lat(q0)
        if (q1.isEmpty()) return null
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: String? = null
        var bestScore = 1.0
        for (ri in apps) {
            val label = ri.loadLabel(pm).toString()
            val l1 = norm(label)
            val l2 = lat(label)
            if (l1.isEmpty()) continue
            var s = minOf(lev(l1, q1).toDouble() / maxOf(l1.length, q1.length), lev(l2, q2).toDouble() / maxOf(l2.length, q2.length, 1))
            if (q2.length >= 3 && (l2.contains(q2) || l1.contains(q1))) s = minOf(s, 0.1)
            if (s < bestScore) { bestScore = s; best = ri.activityInfo.packageName }
        }
        return if (bestScore <= 0.38) best else null
    }

    /** Тихий запуск приложения: без Toast и системных плашек. */
    fun openApp(c: Context, name: String, pkg: String): Boolean {
        val pm = c.packageManager
        var p: String? = if (pkg.isNotBlank() && pm.getLaunchIntentForPackage(pkg) != null) pkg else null
        if (p == null) p = findApp(c, name)
        val i = (if (p != null) pm.getLaunchIntentForPackage(p) else null) ?: return false
        return start(c, i)
    }

    fun settings(c: Context, page: String) {
        if (!start(c, Intent("android.settings." + page))) start(c, Intent(Settings.ACTION_SETTINGS))
    }

    @Volatile var torchState = false
    private var torchCb: CameraManager.TorchCallback? = null

    /** on = null — переключить. */
    fun torch(c: Context, on: Boolean?): Boolean = try {
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        if (torchCb == null) {
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(id: String, enabled: Boolean) { torchState = enabled }
            }
            torchCb = cb
            cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
            Thread.sleep(300)
        }
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id == null) false else { cm.setTorchMode(id, on ?: !torchState); true }
    } catch (e: Exception) { false }

    fun timer(c: Context, sec: Int) {
        start(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    fun alarm(c: Context, h: Int, m: Int) {
        start(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    fun mediaKey(c: Context, code: Int) {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun web(c: Context, url: String) { start(c, Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

    class Ai(val key: String, val base: String, val models: List<String>)
    @Volatile var lastX = -1.0
    @Volatile var lastY = -1.0
    @Volatile var lastAt = 0L

    fun ai(c: Context): Ai? {
        val pr = c.getSharedPreferences("axel", 0)
        val key = pr.getString("key", "") ?: ""
        val base = pr.getString("base", "") ?: ""
        if (key.isEmpty() || base.isEmpty()) return null
        val all = ArrayList<String>()
        try { val a = JSONArray(pr.getString("models", "[]")); for (i in 0 until a.length()) all.add(a.getString(i)) } catch (e: Exception) { }
        return Ai(key, base, all)
    }

    // ---------- скрытые скриншоты: кэш последнего кадра на 4 секунды ----------

    @Volatile private var cacheBmp: Bitmap? = null
    @Volatile private var cacheAt = 0L

    /** Скрытый кадр экрана в реальном разрешении, с кэшем 3–5 с. Только в памяти. */
    fun shotCached(svc: AlterAccessibilityService, maxAgeMs: Long = 4000L): Bitmap? {
        val b = cacheBmp
        if (b != null && System.currentTimeMillis() - cacheAt < maxAgeMs) return b
        val fresh = svc.shotSync() ?: return b
        cacheBmp = fresh
        cacheAt = System.currentTimeMillis()
        return fresh
    }

    fun invalidateShot() { cacheBmp = null }

    /** Высота статус-бара: передаётся в Vision-модель, чтобы координаты не путались с верхней полосой экрана. */
    fun statusBarPx(svc: AlterAccessibilityService): Int = try {
        val id = svc.resources.getIdentifier("status_bar_height", "dimen", "android")
        if (id > 0) svc.resources.getDimensionPixelSize(id) else 0
    } catch (e: Exception) { 0 }

    /** Статус шага в чат («Смотрю на экран…», «Нажимаю на Бойцы…») — без скриншотов. */
    fun status(c: Context, msg: String) {
        val pr = c.getSharedPreferences("axel", 0)
        val arr = try { JSONArray(pr.getString("log", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject(mapOf("status" to msg)))
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 50) until arr.length()) trimmed.put(arr.get(i))
        pr.edit().putString("log", trimmed.toString()).apply()
        MainActivity.inst?.ping()
    }

    // ---------- нажатие кнопок: текст -> дерево экрана + ИИ -> скриншот с сеткой ----------

    /** Зоны экрана словами: «середина», «центр экрана», «верх экрана»… -> доли ширины и высоты. */
    private fun zoneOf(t: String): Pair<Double, Double>? {
        val s = t.lowercase().replace('ё', 'е').trim()
        val screenWord = s.contains("экран") || s.contains("дисплей")
        return when {
            Regex("^(?:в |на |по )?(?:центр|середин)\\w*$").matches(s) -> Pair(0.5, 0.5)
            screenWord && Regex("центр|середин").containsMatchIn(s) -> Pair(0.5, 0.5)
            screenWord && s.contains("верх") -> Pair(0.5, 0.15)
            screenWord && s.contains("низ") -> Pair(0.5, 0.85)
            screenWord && s.contains("лев") -> Pair(0.12, 0.5)
            screenWord && s.contains("прав") -> Pair(0.88, 0.5)
            else -> null
        }
    }

    /** ИИ выбирает из списка видимых элементов тот, что подходит под описание («первое видео», «магазин», «Бойцы»). */
    private fun pickItem(ai: Ai, desc: String, items: List<AlterAccessibilityService.UiItem>): AlterAccessibilityService.UiItem? {
        val sb = StringBuilder()
        for (u in items) {
            sb.append(u.id).append(" | ").append(u.label).append(" | x=").append(u.cx).append(",y=").append(u.cy)
            if (u.clickable) sb.append(" | clickable")
            sb.append('\n')
        }
        val sys = "You control an Android phone. Below is the list of visible UI elements (id | text or description | center | clickable). " +
            "The user wants to tap: «$desc». Choose the ONE element that best matches by meaning (synonyms and other languages count; " +
            "for ordinals like «первое видео» or «second result» take the matching one counting from the top; prefer the clickable item over a plain label inside it). " +
            "Reply ONLY with JSON {\"id\":N}, or {\"id\":0} if nothing fits."
        val ans = Brain.quick(ai, sys, sb.toString(), 80) ?: return null
        val id = Regex("\"id\"\\s*:\\s*(\\d+)").find(ans)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        return items.firstOrNull { it.id == id }
    }

    /**
     * Находит и нажимает элемент «text» — в обычных приложениях и в играх. До 5 шагов:
     * 1) точный/нечёткий поиск по тексту через доступность;
     * 2) список видимых элементов -> ИИ выбирает нужный (понимает «первое видео», синонимы, другой язык);
     * 3) СВЕЖИЙ скрытый скриншот -> модель с сеткой/координатами -> нажатие по центру;
     * 4) если элемента нет на экране — листаем и повторяем.
     */
    fun tapSmart(c: Context, text: String): Pair<Boolean, String> {
        val s = AlterAccessibilityService.instance ?: return Pair(false, "Включите специальные возможности Axel в настройках Android")
        val want = text.trim().trim('«', '»', '"', '\'')
        if (want.isEmpty()) return Pair(false, "Скажите, на что нажать")
        val (w, h) = s.screenSize()
        zoneOf(want)?.let { z ->
            val x = (w * z.first).coerceIn(2.0, (w - 3).toDouble())
            val y = (h * z.second).coerceIn(2.0, (h - 3).toDouble())
            lastX = x; lastY = y; lastAt = System.currentTimeMillis()
            return if (s.tapAt(x, y)) Pair(true, "Нажимаю") else Pair(false, "Не получилось нажать")
        }
        val ai = ai(c)
        status(c, "Смотрю на экран…")
        for (step in 0 until 5) {
            // 1) по тексту
            if (s.findNode(want) != null && s.tap(want).first) {
                status(c, "Нажимаю на «$want»…")
                lastAt = System.currentTimeMillis(); invalidateShot()
                return Pair(true, "Нажимаю «$want»")
            }
            if (ai == null) return Pair(false, "Не нашёл «$want» по тексту на экране. Чтобы я искал кнопки по картинке (в играх), добавьте API-ключ в настройках")
            // 2) дерево элементов + ИИ
            try {
                val items = s.listItems()
                if (items.size >= 2) {
                    val pick = pickItem(ai, want, items)
                    if (pick != null && s.clickItem(pick)) {
                        status(c, "Нажимаю на «$want»…")
                        lastX = pick.cx.toDouble(); lastY = pick.cy.toDouble(); lastAt = System.currentTimeMillis(); invalidateShot()
                        return Pair(true, "Нажимаю «$want»")
                    }
                }
            } catch (e: Exception) { }
            // 3) скриншот (всегда свежий: экран мог измениться после прошлого шага)
            invalidateShot()
            val bmp = s.shotSync() ?: return Pair(false, "Не получилось сделать скрытый снимок экрана — нужен Android 11 или новее и включённые специальные возможности Axel")
            val res = try { Vision.locate(ai.base, ai.key, ai.models, bmp, want, statusBarPx(s)) } catch (e: Exception) { Vision.Res.Miss }
            invalidateShot()
            when (res) {
                is Vision.Res.Found -> {
                    val x = res.x.coerceIn(2, w - 3).toDouble()
                    val y = res.y.coerceIn(2, h - 3).toDouble()
                    status(c, "Нажимаю на «$want»…")
                    lastX = x; lastY = y; lastAt = System.currentTimeMillis()
                    return if (s.tapAt(x, y)) Pair(true, "Нажимаю «$want»") else Pair(false, "Нашёл «$want», но не получилось нажать")
                }
                is Vision.Res.Scroll -> {
                    status(c, "Листаю, ищу «$want»…")
                    s.swipe(res.dir, 0.5f)
                    Thread.sleep(900)
                }
                is Vision.Res.None -> return Pair(false, "Не вижу «$want» на экране — похоже, такой кнопки сейчас нет. Откройте нужный экран или скажите иначе, что нажать")
                else -> break
            }
        }
        val why = Vision.lastErr?.let { " Причина: $it." } ?: ""
        return Pair(false, "Не получилось найти «$want» на экране.$why")
    }

    /** Листать, пока элемент не появится (до 6 раз). */
    fun scrollToSync(c: Context, desc: String, dir: String): Boolean {
        val s = AlterAccessibilityService.instance ?: return false
        val ai = ai(c)
        status(c, "Ищу «$desc»…")
        for (i in 0 until 6) {
            if (s.findNode(desc) != null) return true
            if (ai != null) {
                invalidateShot()
                val bmp = s.shotSync() ?: return false
                val (w, h) = s.screenSize()
                val r = try { Vision.locate(ai.base, ai.key, ai.models, bmp, desc, statusBarPx(s)) } catch (e: Exception) { Vision.Res.Miss }
                if (r is Vision.Res.Found) {
                    lastX = r.x.coerceIn(2, w - 3).toDouble(); lastY = r.y.coerceIn(2, h - 3).toDouble()
                    lastAt = System.currentTimeMillis()
                    return true
                }
                if (r is Vision.Res.Scroll) { s.swipe(r.dir, 0.5f); Thread.sleep(900); continue }
                if (r is Vision.Res.None) { s.swipe(dir, 0.5f); Thread.sleep(1000); continue }
            }
            s.swipe(dir, 0.5f)
            Thread.sleep(1200)
        }
        return false
    }

    /** Поиск внутри любого другого открытого приложения: найти строку поиска -> клик -> вставить текст -> «Поиск». */
    fun searchInApp(c: Context, text: String): Pair<Boolean, String> {
        val s = AlterAccessibilityService.instance ?: return Pair(false, "Включите специальные возможности Axel в настройках Android")
        val field = listOf("поиск", "search", "найти", "найти здесь", "искать", "query", "поискать")
            .mapNotNull { s.findNode(it) }.firstOrNull { it.isEditable || it.isClickable } ?: s.findNode("поиск") ?: s.findNode("search")
        if (field == null) return Pair(false, "Не нашёл строку поиска на экране")
        s.tap("поиск")
        Thread.sleep(700)
        if (!s.typeText(text)) return Pair(false, "Не смог вставить текст в поиск")
        Thread.sleep(600)
        val go = listOf("поиск", "search", "найти", "ввод", "enter", "готово", "done").mapNotNull { s.findNode(it) }.firstOrNull()
        return if (go != null && s.tap(go.text?.toString() ?: "поиск").first) Pair(true, "Ищу «$text»")
        else Pair(true, "Ввёл «$text» в поиск")
    }

    fun tapLast(): Boolean {
        val s = AlterAccessibilityService.instance ?: return false
        if (lastX < 0 || System.currentTimeMillis() - lastAt > 90000) return false
        return s.tapAt(lastX, lastY)
    }
}
