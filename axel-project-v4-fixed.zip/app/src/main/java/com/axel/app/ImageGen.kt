package com.axel.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Генерация картинок БЕЗ Pollinations-лимита (1 картинка / 45 с).
 * Цепочка (первый успех побеждает):
 *  1. OpenRouter — тот же ключ, что и для чата: сами находим бесплатные модели, умеющие рисовать (output = image);
 *  2. Google Gemini image (если выбран Gemini и тариф это позволяет);
 *  3. Pollinations — одна быстрая попытка (если не упёрлись в лимит);
 *  4. AI Horde (Stable Diffusion) — бесплатно и без ключа, но с очередью (до ~2 минут).
 * Готовая картинка сохраняется в filesDir/gen и отдаётся в чат по адресу https://appassets.androidplatform.net/gen/<файл>.
 */
object ImageGen {
    class Out(val file: File?, val err: String?) {
        val url: String? get() = file?.let { "https://appassets.androidplatform.net/gen/" + it.name }
    }

    private class Http(val code: Int, val body: ByteArray, val type: String) {
        fun text(): String = try { String(body, Charsets.UTF_8) } catch (e: Exception) { "" }
    }

    private const val HORDE = "https://aihorde.net/api/v2"

    private fun http(method: String, url: String, headers: Map<String, String>, body: ByteArray?, readMs: Int): Http {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = method
        con.connectTimeout = 10000
        con.readTimeout = readMs
        con.instanceFollowRedirects = true
        for ((k, v) in headers) con.setRequestProperty(k, v)
        if (body != null) { con.doOutput = true; con.outputStream.use { it.write(body) } }
        val code = con.responseCode
        val stream = if (code in 200..299) con.inputStream else con.errorStream
        val bytes = try { stream?.readBytes() ?: ByteArray(0) } catch (e: Exception) { ByteArray(0) }
        return Http(code, bytes, con.contentType ?: "")
    }

    private fun short(s: String): String = s.replace(Regex("\\s+"), " ").trim().take(160)

    /** Проверяем, что это настоящая картинка, и приводим к JPEG (WebView стабильно показывает его с любого источника). */
    private fun normalize(bytes: ByteArray): ByteArray? {
        if (bytes.size < 2000) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth < 64 || o.outHeight < 64) return null
        var sample = 1
        while (o.outWidth / sample > 2048 || o.outHeight / sample > 2048) sample *= 2
        val bmp: Bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 92, bo)
        return bo.toByteArray()
    }

    private fun save(c: Context, jpeg: ByteArray): File {
        val dir = File(c.filesDir, "gen")
        dir.mkdirs()
        val f = File(dir, "img_" + System.currentTimeMillis() + ".jpg")
        f.writeBytes(jpeg)
        try { dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(40)?.forEach { it.delete() } } catch (e: Exception) { }
        return f
    }

    /** Достаём картинку из ответа OpenRouter (message.images[] или image_url внутри content[]). */
    private fun imageFromChat(j: JSONObject): ByteArray? {
        val msg = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: return null
        val urls = ArrayList<String>()
        msg.optJSONArray("images")?.let { arr ->
            for (i in 0 until arr.length()) {
                val u = arr.optJSONObject(i)?.optJSONObject("image_url")?.optString("url") ?: ""
                if (u.isNotBlank()) urls.add(u)
            }
        }
        val content = msg.opt("content")
        if (content is JSONArray) {
            for (i in 0 until content.length()) {
                val u = content.optJSONObject(i)?.optJSONObject("image_url")?.optString("url") ?: ""
                if (u.isNotBlank()) urls.add(u)
            }
        }
        for (u in urls) {
            if (u.startsWith("data:")) {
                val b64 = u.substringAfter("base64,", "")
                if (b64.isNotEmpty()) return try { Base64.decode(b64, Base64.DEFAULT) } catch (e: Exception) { null }
            } else if (u.startsWith("http")) {
                val r = http("GET", u, emptyMap(), null, 60000)
                if (r.code in 200..299) return r.body
            }
        }
        return null
    }

    /** Модели OpenRouter, которые умеют РИСОВАТЬ: сначала бесплатные, затем самые дешёвые. */
    private fun orModels(ai: Phone.Ai): List<String> {
        val free = ArrayList<String>()
        val paid = ArrayList<Pair<Double, String>>()
        try {
            val r = http("GET", ai.base + "/models?output_modalities=image", mapOf("Authorization" to "Bearer " + ai.key), null, 15000)
            if (r.code in 200..299) {
                val arr = JSONObject(r.text()).optJSONArray("data")
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = o.optString("id")
                    if (id.isBlank()) continue
                    val outs = o.optJSONObject("architecture")?.optJSONArray("output_modalities")
                    var draws = false
                    if (outs != null) for (k in 0 until outs.length()) if (outs.optString(k) == "image") draws = true
                    if (!draws) continue
                    val pr = o.optJSONObject("pricing")
                    val p = pr?.optString("prompt")?.toDoubleOrNull() ?: 0.0
                    val cm = pr?.optString("completion")?.toDoubleOrNull() ?: 0.0
                    if (id.endsWith(":free") || (p == 0.0 && cm == 0.0)) free.add(id) else paid.add(Pair(p + cm, id))
                }
            }
        } catch (e: Exception) { }
        if (free.isEmpty()) free.add("recraft/recraft-v4.1-flash-v2:free")
        return (free.take(3) + paid.sortedBy { it.first }.take(1).map { it.second }).distinct()
    }

    private fun viaOpenRouter(ai: Phone.Ai, prompt: String, errs: MutableList<String>): ByteArray? {
        for (m in orModels(ai)) {
            for (mods in listOf(listOf("image", "text"), listOf("image"))) {
                try {
                    val body = JSONObject().put("model", m)
                        .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                        .put("modalities", JSONArray(mods))
                    val r = http("POST", ai.base + "/chat/completions",
                        mapOf("Content-Type" to "application/json", "Authorization" to "Bearer " + ai.key), body.toString().toByteArray(), 120000)
                    if (r.code in 200..299) {
                        val img = imageFromChat(JSONObject(r.text()))
                        if (img != null) return img
                        errs.add("$m: пустой ответ")
                        break
                    }
                    if (r.code == 400 && mods.size == 2) continue // модель только для картинок — пробуем modalities=["image"]
                    errs.add("$m: " + r.code + " " + short(r.text()))
                    break
                } catch (e: Exception) { errs.add("$m: " + (e.message ?: "сбой сети")); break }
            }
        }
        return null
    }

    private fun viaGemini(ai: Phone.Ai, prompt: String, errs: MutableList<String>): ByteArray? {
        try {
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
            val r = http("POST", ai.base + "/models/gemini-2.5-flash-image:generateContent?key=" + ai.key,
                mapOf("Content-Type" to "application/json"), body.toString().toByteArray(), 90000)
            if (r.code !in 200..299) { errs.add("Gemini: " + r.code + " " + short(r.text())); return null }
            val parts = JSONObject(r.text()).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            if (parts != null) for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                val d = (p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data"))?.optString("data") ?: ""
                if (d.isNotEmpty()) return Base64.decode(d, Base64.DEFAULT)
            }
            errs.add("Gemini: пустой ответ")
        } catch (e: Exception) { errs.add("Gemini: " + (e.message ?: "сбой сети")) }
        return null
    }

    private fun viaPollinations(prompt: String, errs: MutableList<String>): ByteArray? {
        val q = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        val seed = System.currentTimeMillis()
        val variants = listOf(
            "https://image.pollinations.ai/prompt/$q?width=1024&height=1024&model=flux&nologo=true&seed=$seed",
            "https://image.pollinations.ai/prompt/$q?width=768&height=768&seed=$seed"
        )
        for (u in variants) {
            try {
                val r = http("GET", u, mapOf("User-Agent" to "Axel/4.0"), null, 70000)
                if (r.code == 429) { errs.add("Pollinations: лимит, 1 картинка в 45 с"); return null }
                if (r.code in 200..299 && r.type.startsWith("image")) return r.body
                errs.add("Pollinations: " + r.code)
            } catch (e: Exception) { errs.add("Pollinations: " + (e.message ?: "сбой сети")) }
        }
        return null
    }

    private fun viaHorde(prompt: String, progress: (String) -> Unit, errs: MutableList<String>): ByteArray? {
        try {
            val h = mapOf("apikey" to "0000000000", "Client-Agent" to "axel:4:axel-app", "Content-Type" to "application/json")
            val body = JSONObject().put("prompt", prompt)
                .put("params", JSONObject().put("n", 1).put("width", 512).put("height", 512).put("steps", 25).put("cfg_scale", 7).put("sampler_name", "k_euler_a"))
                .put("nsfw", false).put("censor_nsfw", true).put("trusted_workers", false).put("slow_workers", true).put("r2", true)
            val st = http("POST", "$HORDE/generate/async", h, body.toString().toByteArray(), 30000)
            if (st.code !in 200..299) { errs.add("Horde: " + st.code + " " + short(st.text())); return null }
            val id = JSONObject(st.text()).optString("id")
            if (id.isBlank()) { errs.add("Horde: нет id задачи"); return null }
            var waited = 0
            var done = false
            while (waited < 150) {
                Thread.sleep(3000); waited += 3
                val ck = http("GET", "$HORDE/generate/check/$id", h, null, 20000)
                if (ck.code !in 200..299) continue
                val j = JSONObject(ck.text())
                if (j.optBoolean("done")) { done = true; break }
                if (j.optBoolean("faulted")) { errs.add("Horde: сбой воркера"); return null }
                if (waited % 15 == 0) {
                    val pos = j.optInt("queue_position", -1)
                    progress(if (pos > 0) "Рисую… я в очереди бесплатного сервиса (место $pos)" else "Рисую… ещё немного")
                }
            }
            if (!done) { errs.add("Horde: слишком длинная очередь"); return null }
            val fin = http("GET", "$HORDE/generate/status/$id", h, null, 30000)
            val gens = JSONObject(fin.text()).optJSONArray("generations")
            val img = gens?.optJSONObject(0)?.optString("img") ?: ""
            if (img.isBlank()) { errs.add("Horde: пустой результат"); return null }
            if (img.startsWith("http")) {
                val d = http("GET", img, emptyMap(), null, 60000)
                if (d.code in 200..299) return d.body
                errs.add("Horde: не скачалась картинка " + d.code)
                return null
            }
            return Base64.decode(img, Base64.DEFAULT)
        } catch (e: Exception) { errs.add("Horde: " + (e.message ?: "сбой сети")) }
        return null
    }

    /** Блокирующий вызов — только из фонового потока. prompt уже на английском. */
    fun generate(c: Context, ai: Phone.Ai?, prompt: String, progress: (String) -> Unit): Out {
        val errs = ArrayList<String>()
        val steps = ArrayList<() -> ByteArray?>()
        if (ai != null && ai.base.contains("openrouter")) steps.add { viaOpenRouter(ai, prompt, errs) }
        if (ai != null && ai.base.contains("generativelanguage")) steps.add { viaGemini(ai, prompt, errs) }
        steps.add { viaPollinations(prompt, errs) }
        steps.add { viaHorde(prompt, progress, errs) }
        for (s in steps) {
            val raw: ByteArray? = try { s() } catch (e: Exception) { null }
            if (raw == null) continue
            val jpeg = normalize(raw)
            if (jpeg == null) { errs.add("получен не файл картинки"); continue }
            return Out(save(c, jpeg), null)
        }
        return Out(null, errs.takeLast(3).joinToString("; "))
    }
}
