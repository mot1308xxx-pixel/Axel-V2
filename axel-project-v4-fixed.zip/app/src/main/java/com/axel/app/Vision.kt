package com.axel.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/**
 * Скрытое зрение Axel: скриншот живёт только в памяти и в чат не попадает.
 *
 * Как находим кнопку (в играх, где система доступности ничего не видит):
 *  • Gemini — модель сама возвращает рамку box_2d (0..1000), это её родной и точный формат;
 *  • остальные модели (OpenRouter и т. д.) плохо считают пиксели, поэтому рисуем на скриншоте СЕТКУ с подписями клеток (A1, B7…),
 *    модель называет клетку с центром кнопки, затем мы увеличиваем эту область, рисуем более частую сетку и уточняем.
 */
object Vision {
    sealed class Res {
        data class Found(val x: Int, val y: Int) : Res()
        data class Scroll(val dir: String) : Res()
        object None : Res()
        object Miss : Res()
    }

    /** Причина последнего сбоя (лимит модели, ошибка сети…) — показывается пользователю. */
    @Volatile var lastErr: String? = null

    private fun models(base: String, all: List<String>): List<String> {
        val vis = all.filter { Regex("flash|gemini|vl|vision|llama-4|pixtral|gpt-4o|gpt-4\\.1|omni|gemma-4|ling").containsMatchIn(it.lowercase()) }
        val pick = when {
            base.contains("generativelanguage") -> listOf("gemini-2.5-flash", "gemini-2.5-flash-lite")
            base.contains("openrouter") -> listOf(
                "nvidia/nemotron-3.5-super-vl:free", "google/gemma-4-26b-a4b-it:free",
                "inclusionai/ling-3.2-flash:free", "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free")
            base.contains("groq") -> listOf("meta-llama/llama-4-scout-17b-16e-instruct", "meta-llama/llama-4-maverick-17b-128e-instruct")
            base.contains("openai") -> listOf("gpt-4o-mini", "gpt-4.1-mini", "gpt-4o")
            base.contains("mistral") -> listOf("mistral-small-latest", "pixtral-12b-latest")
            else -> emptyList()
        }
        val list = if (base.contains("generativelanguage")) (vis.filter { it.contains("flash") } + pick) else (pick + vis)
        return list.distinct().take(4)
    }

    private fun jpegB64(b: Bitmap): String {
        val bo = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 85, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    /** Рисует на копии картинки сетку cols x rows с подписями клеток: A1, B1, … (буква — столбец, число — строка). */
    private fun gridded(src: Bitmap, cols: Int, rows: Int): Bitmap {
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true)
        val cv = Canvas(bmp)
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val line = Paint().apply { color = Color.argb(170, 255, 40, 40); strokeWidth = maxOf(1.5f, w / 350f) }
        val bg = Paint().apply { color = Color.argb(215, 0, 0, 0) }
        val tp = Paint().apply { color = Color.YELLOW; isAntiAlias = true; isFakeBoldText = true; textSize = (w / cols) / 3.3f }
        for (i in 1 until cols) cv.drawLine(w * i / cols, 0f, w * i / cols, h, line)
        for (j in 1 until rows) cv.drawLine(0f, h * j / rows, w, h * j / rows, line)
        for (i in 0 until cols) for (j in 0 until rows) {
            val label = ('A' + i).toString() + (j + 1)
            val x = w * i / cols
            val y = h * j / rows
            val tw = tp.measureText(label)
            cv.drawRect(x + 2f, y + 2f, x + tw + 12f, y + tp.textSize + 10f, bg)
            cv.drawText(label, x + 7f, y + tp.textSize + 3f, tp)
        }
        return bmp
    }

    /** Один запрос к модели с картинкой. null — сбой (причина в lastErr). */
    private fun call(base: String, key: String, model: String, b64: String, prompt: String): String? {
        val gem = base.contains("generativelanguage")
        val url = if (gem) "$base/models/$model:generateContent?key=$key" else "$base/chat/completions"
        val variants = if (!gem && base.contains("openrouter")) listOf(true, false) else listOf(false)
        for (reasoning in variants) {
            val body: JSONObject = if (gem) {
                JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
                    .put(JSONObject().put("text", prompt))
                    .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64))))))
                    .put("generationConfig", JSONObject().put("temperature", 0).put("maxOutputTokens", 400)
                        .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
            } else {
                val txt = JSONObject().put("type", "text").put("text", prompt)
                val img = JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
                val o = JSONObject().put("model", model).put("temperature", 0).put("max_tokens", 1500)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", JSONArray().put(txt).put(img))))
                if (reasoning) o.put("reasoning", JSONObject().put("effort", "low").put("exclude", true))
                o
            }
            val con = URL(url).openConnection() as HttpURLConnection
            con.requestMethod = "POST"
            con.connectTimeout = 8000
            con.readTimeout = 40000
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            if (!gem) con.setRequestProperty("Authorization", "Bearer $key")
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = con.responseCode
            if (code !in 200..299) {
                val et = try { con.errorStream?.bufferedReader()?.readText()?.replace(Regex("\\s+"), " ")?.take(160) } catch (e: Exception) { null }
                lastErr = if (code == 429) "лимит запросов модели ($model), подождите минуту" else "модель $model вернула ошибку $code" + (if (et.isNullOrBlank()) "" else ": $et")
                if (code == 400 && reasoning) continue // эта модель не знает параметр reasoning — повторяем без него
                return null
            }
            val j = JSONObject(con.inputStream.bufferedReader().readText())
            if (gem) {
                val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return null
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.optJSONObject(i) ?: continue
                    if (!p.isNull("text")) sb.append(p.optString("text"))
                }
                return Brain.cleanTextPublic(sb.toString())
            }
            return Brain.extractContent(j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: return null)
        }
        return null
    }

    /** Последний JSON-объект со словом status из ответа модели. */
    private fun statusJson(ans: String): String? =
        Regex("\\{[^{}]*\"status\"[^{}]*\\}").findAll(ans).lastOrNull()?.value

    private fun field(js: String, k: String): String? =
        Regex("\"$k\"\\s*:\\s*\"([^\"]*)\"").find(js)?.groupValues?.get(1)

    private fun cellOf(js: String, cols: Int, rows: Int): Pair<Int, Int>? {
        val m = Regex("\"cell\"\\s*:\\s*\"\\s*([A-Za-z])\\s*([0-9]{1,2})").find(js) ?: return null
        val c = m.groupValues[1].uppercase()[0] - 'A'
        val r = m.groupValues[2].toInt() - 1
        return if (c in 0 until cols && r in 0 until rows) Pair(c, r) else null
    }

    private fun rules(desc: String, sb: Int): String =
        "TASK: find the on-screen element described as «$desc» (a button, tab, icon, card, list item, video thumbnail or text; the screen language may be Russian or English — match by meaning, ignore letter case). " +
        (if (sb > 0) "The top ~$sb px of the real screen is the status bar (no buttons there). " else "")

    private const val TAIL =
        "If it is not visible but is probably further away in a scrollable screen reply {\"status\":\"scroll\",\"direction\":\"down\"} (direction: down, up, left or right = where to swipe/scroll). " +
        "If it is definitely not on this screen and scrolling will not help reply {\"status\":\"none\"}. Reply with ONE JSON object only, no other text."

    // ---------- Gemini: родные координаты ----------
    private fun locateNative(base: String, key: String, model: String, bmp: Bitmap, desc: String, sb: Int): Res? {
        val W = bmp.width
        val H = bmp.height
        val k = minOf(1.0, 1600.0 / maxOf(W, H))
        val small = if (k < 1.0) Bitmap.createScaledBitmap(bmp, (W * k).toInt(), (H * k).toInt(), true) else bmp
        val prompt = "This is a screenshot of an Android phone. " + rules(desc, sb) +
            "If you can see it, reply {\"status\":\"found\",\"box_2d\":[ymin,xmin,ymax,xmax]} where the box tightly surrounds the element and the numbers are normalized to the range 0-1000 (ymin = top, xmin = left). " + TAIL
        val ans = call(base, key, model, jpegB64(small), prompt) ?: return null
        val js = statusJson(ans) ?: return null
        when (field(js, "status")?.lowercase()) {
            "scroll" -> return Res.Scroll(Regex("(down|up|left|right)").find(field(js, "direction") ?: "down")?.value ?: "down")
            "none" -> return Res.None
            "found" -> {
                val bx = Regex("\"box_2d\"\\s*:\\s*\\[\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*,\\s*([0-9.]+)").find(js) ?: return null
                val g = bx.groupValues.drop(1).map { it.toDouble() }
                if (g.any { it < 0.0 || it > 1000.0 }) return null
                val cx = ((g[1] + g[3]) / 2000.0 * W).toInt().coerceIn(2, W - 3)
                val cy = ((g[0] + g[2]) / 2000.0 * H).toInt().coerceIn(2, H - 3)
                return Res.Found(cx, cy)
            }
        }
        return null
    }

    // ---------- остальные модели: сетка + уточнение ----------
    private fun locateGrid(base: String, key: String, model: String, bmp: Bitmap, desc: String, sb: Int): Res? {
        val W = bmp.width
        val H = bmp.height
        val k = minOf(1.0, 1600.0 / maxOf(W, H))
        val small = if (k < 1.0) Bitmap.createScaledBitmap(bmp, (W * k).toInt(), (H * k).toInt(), true) else bmp
        val cols = 6
        val rows = (cols * small.height.toDouble() / small.width).roundToInt().coerceIn(6, 16)
        val prompt = "This is a screenshot of an Android phone with a labeled grid drawn over it. Every cell has a label in its top-left corner: a LETTER = column (A, B, C… from left to right) and a NUMBER = row (1, 2, 3… from top to bottom), e.g. C7. " +
            rules(desc, sb) +
            "If you can see it, reply {\"status\":\"found\",\"cell\":\"C7\"} where the cell is the one that contains the CENTER of the element (use the exact label printed in that cell). " + TAIL
        val ans = call(base, key, model, jpegB64(gridded(small, cols, rows)), prompt) ?: return null
        val js = statusJson(ans) ?: return null
        when (field(js, "status")?.lowercase()) {
            "scroll" -> return Res.Scroll(Regex("(down|up|left|right)").find(field(js, "direction") ?: "down")?.value ?: "down")
            "none" -> return Res.None
            "found" -> {
                val (ci, ri) = cellOf(js, cols, rows) ?: return null
                val cw = W.toDouble() / cols
                val ch = H.toDouble() / rows
                var fx = (ci + 0.5) * cw
                var fy = (ri + 0.5) * ch
                try {
                    refine(base, key, model, bmp, desc, ci, ri, cols, rows)?.let { fx = it.first; fy = it.second }
                } catch (e: Exception) { }
                return Res.Found(fx.toInt().coerceIn(2, W - 3), fy.toInt().coerceIn(2, H - 3))
            }
        }
        return null
    }

    /** Второй проход: вырезаем область 3x3 клетки вокруг найденной, увеличиваем, рисуем частую сетку и уточняем центр. */
    private fun refine(base: String, key: String, model: String, bmp: Bitmap, desc: String, ci: Int, ri: Int, cols: Int, rows: Int): Pair<Double, Double>? {
        val W = bmp.width
        val H = bmp.height
        val cw = W.toDouble() / cols
        val ch = H.toDouble() / rows
        val x0 = maxOf(0.0, (ci - 1) * cw).toInt()
        val y0 = maxOf(0.0, (ri - 1) * ch).toInt()
        val x1 = minOf(W.toDouble(), (ci + 2) * cw).toInt()
        val y1 = minOf(H.toDouble(), (ri + 2) * ch).toInt()
        val rw = x1 - x0
        val rh = y1 - y0
        if (rw < 60 || rh < 60) return null
        val crop = Bitmap.createBitmap(bmp, x0, y0, rw, rh)
        val sc = 1000.0 / maxOf(rw, rh)
        val z = Bitmap.createScaledBitmap(crop, (rw * sc).toInt().coerceAtLeast(1), (rh * sc).toInt().coerceAtLeast(1), true)
        val c2 = 5
        val r2 = (c2 * z.height.toDouble() / z.width).roundToInt().coerceIn(3, 8)
        val prompt = "This is a zoomed-in part of an Android phone screen with a labeled grid drawn over it (LETTER = column from the left, NUMBER = row from the top, e.g. B3). " +
            "TASK: find the element described as «$desc». Reply {\"status\":\"found\",\"cell\":\"B3\"} where the cell contains the CENTER of that element, " +
            "or {\"status\":\"none\"} if it is not in this picture. ONE JSON object only."
        val ans = call(base, key, model, jpegB64(gridded(z, c2, r2)), prompt) ?: return null
        val js = statusJson(ans) ?: return null
        if (field(js, "status")?.lowercase() != "found") return null
        val (cj, rj) = cellOf(js, c2, r2) ?: return null
        return Pair(x0 + (cj + 0.5) / c2 * rw, y0 + (rj + 0.5) / r2 * rh)
    }

    /**
     * Ищет элемент на скрытом скриншоте. bmp — кадр в реальном разрешении экрана.
     * Возвращает центр в физических пикселях, команду «листать», None («такого нет») или Miss (модели не ответили).
     * Вызывать не в основном потоке.
     */
    fun locate(base: String, key: String, all: List<String>, bmp: Bitmap, desc: String, statusBarPx: Int = 0): Res {
        lastErr = null
        val gem = base.contains("generativelanguage")
        for (m in models(base, all)) {
            try {
                val r = if (gem) (locateNative(base, key, m, bmp, desc, statusBarPx) ?: locateGrid(base, key, m, bmp, desc, statusBarPx))
                        else locateGrid(base, key, m, bmp, desc, statusBarPx)
                if (r != null) return r
            } catch (e: Exception) { lastErr = e.message ?: "сбой сети" }
        }
        return Res.Miss
    }
}
