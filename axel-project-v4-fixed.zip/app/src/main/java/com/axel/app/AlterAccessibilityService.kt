package com.axel.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Служба специальных возможностей Axel: реальные нажатия dispatchGesture, свайпы, ввод текста
 *  и СКРЫТЫЕ скриншоты (только в оперативной памяти, с кэшем последнего кадра 3–5 секунд). */
class AlterAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: AlterAccessibilityService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun roots(): List<AccessibilityNodeInfo> {
        val r = ArrayList<AccessibilityNodeInfo>()
        try { windows.forEach { w -> w.root?.let { r.add(it) } } } catch (e: Exception) { }
        rootInActiveWindow?.let { r.add(it) }
        return r
    }

    private fun norm(s: String) = s.lowercase().replace('ё', 'е').trim()

    private fun labelOf(n: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        if (Build.VERSION.SDK_INT >= 30) n.stateDescription?.let { sb.append(it) }
        return norm(sb.toString())
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = t
            }
        }
        return d[b.length]
    }

    /** Подпись элемента: текст, а если он пуст — описание (content description). */
    private fun captionOf(n: AccessibilityNodeInfo): String {
        val t = n.text?.toString()?.trim().orEmpty()
        if (t.isNotEmpty()) return t
        return n.contentDescription?.toString()?.trim().orEmpty()
    }

    /** Лучший по совпадению видимый элемент с таким текстом (точное -> по началу -> по вхождению -> с опечаткой). */
    fun findNode(text: String): AccessibilityNodeInfo? {
        val q = norm(text)
        if (q.isEmpty()) return null
        var best: AccessibilityNodeInfo? = null
        var bs = Int.MAX_VALUE
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = norm(captionOf(n))
            if (t.isNotEmpty() && n.isVisibleToUser) {
                val s = when {
                    t == q -> 0
                    t.startsWith(q) || t.endsWith(q) -> 1 + minOf(t.length - q.length, 50)
                    t.contains(q) -> 60 + minOf(t.length - q.length, 100)
                    t.length >= 3 && q.contains(t) -> 200 + (q.length - t.length)
                    q.length >= 4 && t.length <= 30 && lev(t, q).toDouble() / maxOf(t.length, q.length) <= 0.30 -> 400 + lev(t, q) * 10
                    else -> Int.MAX_VALUE
                }
                if (s < bs) { bs = s; best = n }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        roots().forEach { walk(it) }
        return best
    }

    /** Элемент экрана для выбора ИИ: номер, подпись, центр в пикселях. */
    class UiItem(val id: Int, val label: String, val cx: Int, val cy: Int, val clickable: Boolean, val node: AccessibilityNodeInfo)

    /** Снимок интерфейса: видимые элементы с подписью или кликабельные (до max штук), сверху вниз. Свои окна Axel пропускаем. */
    fun listItems(max: Int = 70): List<UiItem> {
        val (sw, sh) = screenSize()
        val raw = ArrayList<UiItem>()
        val seen = HashSet<String>()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 30) return
            if (n.packageName?.toString() == packageName) return
            if (n.isVisibleToUser) {
                val cap = captionOf(n).replace(Regex("\\s+"), " ").take(70)
                val r = Rect(); n.getBoundsInScreen(r)
                val okSize = r.width() >= 8 && r.height() >= 8 && r.right > 0 && r.bottom > 0 && r.left < sw && r.top < sh
                if (okSize && (cap.isNotEmpty() || (n.isClickable && n.childCount == 0))) {
                    val key = cap + "|" + r.centerX() + "|" + r.centerY()
                    if (seen.add(key)) {
                        val label = if (cap.isNotEmpty()) cap else "(без названия, " + (n.className?.toString()?.substringAfterLast('.') ?: "элемент") + ")"
                        raw.add(UiItem(0, label, r.centerX().coerceIn(2, sw - 3), r.centerY().coerceIn(2, sh - 3), n.isClickable, n))
                    }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        roots().forEach { walk(it, 0) }
        val sorted = raw.sortedWith(compareBy<UiItem>({ it.cy / 40 }, { it.cx }))
        return sorted.take(max).mapIndexed { i, u -> UiItem(i + 1, u.label, u.cx, u.cy, u.clickable, u.node) }
    }

    /** Нажать выбранный элемент: ACTION_CLICK у него или родителя, а если не вышло — настоящий жест по центру. */
    fun clickItem(u: UiItem): Boolean {
        if (clickNode(u.node)) return true
        return tapAt(u.cx.toDouble(), u.cy.toDouble())
    }

    fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var d = 0
        while (n != null && d < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            d++
        }
        val r = Rect(); node.getBoundsInScreen(r)
        return tapAt(r.exactCenterX().toDouble(), r.exactCenterY().toDouble())
    }

    fun tap(text: String): Pair<Boolean, String> {
        val node = findNode(text) ?: return Pair(false, "Не нашёл на экране надпись «$text». В играх кнопки часто не видны системе.")
        val ok = clickNode(node)
        return Pair(ok, if (ok) "Нажал «$text»" else "Не удалось нажать")
    }

    private fun collect(n: AccessibilityNodeInfo?, d: Int, sb: StringBuilder) {
        if (n == null || d > 2) return
        sb.append(' ').append(labelOf(n))
        for (i in 0 until n.childCount) collect(n.getChild(i), d + 1, sb)
    }

    private fun findTile(labels: List<String>): AccessibilityNodeInfo? {
        val rs = roots()
        for (lab in labels) {
            var found: AccessibilityNodeInfo? = null
            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null || found != null) return
                val t = labelOf(n)
                if (t.contains(lab) && !(lab == "интернет" && t.contains("мобильн"))) { found = n; return }
                for (i in 0 until n.childCount) walk(n.getChild(i))
            }
            rs.forEach { walk(it) }
            if (found != null) return found
        }
        return null
    }

    private fun checkedOf(n: AccessibilityNodeInfo): Boolean? {
        var p: AccessibilityNodeInfo? = n
        var d = 0
        while (p != null && d < 4) { if (p.isCheckable) return p.isChecked; p = p.parent; d++ }
        return null
    }

    /** 0 — не нашёл, 1 — переключил, 2 — уже в нужном состоянии. */
    private fun clickTile(n: AccessibilityNodeInfo, on: Boolean?): Int {
        val sb = StringBuilder()
        collect(n, 0, sb)
        var p = n.parent
        var d = 0
        while (p != null && d < 2) { sb.append(' ').append(labelOf(p)); p = p.parent; d++ }
        val s = sb.toString()
        val cur: Boolean? = when {
            Regex("выкл|\\boff\\b|disabled").containsMatchIn(s) -> false
            Regex("вкл|\\bon\\b|enabled").containsMatchIn(s) -> true
            else -> checkedOf(n)
        }
        if (on != null && cur == on) return 2
        clickNode(n)
        return 1
    }

    /** Открывает шторку быстрых настроек и нажимает нужную плитку (защита глаз, Wi-Fi и т. д.). */
    fun toggleTile(labels: List<String>, on: Boolean?): Int {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        Thread.sleep(1100)
        var res = 0
        for (attempt in 0..4) {
            val n = findTile(labels)
            if (n != null) { res = clickTile(n, on); break }
            when (attempt) {
                0 -> swipeAbs(0.5f, 0.12f, 0.5f, 0.7f)
                1, 2 -> swipeAbs(0.85f, 0.4f, 0.15f, 0.4f)
                else -> swipeAbs(0.15f, 0.4f, 0.85f, 0.4f)
            }
            Thread.sleep(800)
        }
        Thread.sleep(300)
        performGlobalAction(GLOBAL_ACTION_BACK)
        return res
    }

    fun typeText(t: String): Boolean {
        var f: AccessibilityNodeInfo? = null
        for (r in roots()) { f = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT); if (f != null) break }
        if (f == null) {
            var ed: AccessibilityNodeInfo? = null
            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null || ed != null) return
                if (n.isEditable && n.isVisibleToUser) { ed = n; return }
                for (i in 0 until n.childCount) walk(n.getChild(i))
            }
            roots().forEach { walk(it) }
            ed?.let { clickNode(it); Thread.sleep(500); f = it }
        }
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return f?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b) ?: false
    }

    /** СКРЫТЫЙ снимок экрана: только в оперативной памяти, никакого сохранения и отправки в чат. */
    fun shot(cb: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, ContextCompat.getMainExecutor(this), object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                cb(bmp)
            }
            override fun onFailure(code: Int) { cb(null) }
        })
    }

    fun tapAt(x: Double, y: Double): Boolean {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 90)).build(), null, null)
    }

    private fun swipeAbs(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val m = resources.displayMetrics
        val p = Path().apply { moveTo(m.widthPixels * x1, m.heightPixels * y1); lineTo(m.widthPixels * x2, m.heightPixels * y2) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build(), null, null)
    }

    /** Плавный свайп в направлении dir (down = контент уезжает вверх, список листается вниз). */
    fun swipe(dir: String, frac: Float = 0.5f): Boolean {
        val a = 0.5f + frac / 2
        val b = 0.5f - frac / 2
        return when (dir) {
            "down" -> swipeAbs(0.5f, a, 0.5f, b)
            "up" -> swipeAbs(0.5f, b, 0.5f, a)
            "left" -> swipeAbs(a, 0.5f, b, 0.5f)
            else -> swipeAbs(b, 0.5f, a, 0.5f)
        }
    }

    /** Реальное разрешение экрана устройства в пикселях. */
    fun screenSize(): Pair<Int, Int> {
        val m = resources.displayMetrics
        return Pair(m.widthPixels, m.heightPixels)
    }

    /** Снимок экрана с ожиданием. Нельзя вызывать из основного потока. */
    fun shotSync(): Bitmap? {
        val box = arrayOfNulls<Bitmap>(1)
        for (attempt in 0..1) {
            val latch = CountDownLatch(1)
            shot { b -> box[0] = b; latch.countDown() }
            latch.await(4, TimeUnit.SECONDS)
            if (box[0] != null) return box[0]
            Thread.sleep(1200)
        }
        return null
    }
}
