package com.axel.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Исполнитель действий Axel. Всё вызывается из фонового потока. Тихий запуск: без Toast. */
object Actions {
    class R(val ok: Boolean, val msg: String, val info: Boolean = false)

    val TILES = mapOf(
        "wifi" to listOf("wi-fi", "wifi", "вай-фай", "wlan", "интернет", "internet"),
        "bluetooth" to listOf("bluetooth", "блютуз"),
        "mobile_data" to listOf("мобильный интернет", "мобильные данные", "mobile data", "передача данных", "сотовые данные"),
        "airplane" to listOf("режим полета", "авиарежим", "в самолете", "airplane", "flight mode"),
        "rotation" to listOf("автоповорот", "автоматический поворот", "auto-rotate", "auto rotate", "поворот экрана", "портрет"),
        "eye_comfort" to listOf("защита глаз", "комфорт для глаз", "защита зрения", "режим чтения", "ночной свет", "night light", "eye comfort", "для глаз", "фильтр синего", "blue light"),
        "dnd" to listOf("не беспокоить", "do not disturb"),
        "battery_saver" to listOf("экономия заряда", "энергосбережение", "battery saver", "экономия энергии"),
        "hotspot" to listOf("точка доступа", "hotspot", "режим модема", "модем"),
        "nfc" to listOf("nfc"),
        "location" to listOf("геолокация", "местоположение", "location", "gps"),
        "dark_mode" to listOf("темная тема", "тёмная тема", "dark mode", "dark theme", "темный режим")
    )
    private val NAMES = mapOf("wifi" to "Wi-Fi", "bluetooth" to "Bluetooth", "mobile_data" to "Мобильный интернет", "airplane" to "Режим полёта",
        "rotation" to "Автоповорот", "eye_comfort" to "Защита глаз", "dnd" to "Не беспокоить", "battery_saver" to "Экономия заряда",
        "hotspot" to "Точка доступа", "nfc" to "NFC", "location" to "Геолокация", "dark_mode" to "Тёмная тема")
    private val PAGES = mapOf("wifi" to "WIFI_SETTINGS", "bluetooth" to "BLUETOOTH_SETTINGS", "display" to "DISPLAY_SETTINGS", "sound" to "SOUND_SETTINGS",
        "battery" to "BATTERY_SAVER_SETTINGS", "location" to "LOCATION_SOURCE_SETTINGS", "apps" to "APPLICATION_SETTINGS", "airplane" to "AIRPLANE_MODE_SETTINGS",
        "nfc" to "NFC_SETTINGS", "date" to "DATE_SETTINGS", "accessibility" to "ACCESSIBILITY_SETTINGS", "storage" to "INTERNAL_STORAGE_SETTINGS", "main" to "SETTINGS")

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun tri(a: JSONObject, k: String): Boolean? {
        if (!a.has(k) || a.isNull(k)) return null
        val v = a.get(k)
        if (v is Boolean) return v
        if (v is Number) return v.toInt() != 0
        return when (v.toString().lowercase()) {
            "true", "on", "вкл", "1", "да" -> true
            "false", "off", "выкл", "0", "нет" -> false
            else -> null
        }
    }

    private fun needsScreen(a: JSONObject): Boolean = when (a.optString("a")) {
        "tap", "tap_geo", "swipe", "scroll_to", "type_text", "search_in_app" -> true
        "global" -> a.optString("cmd") in setOf("back", "recents", "screenshot")
        else -> false
    }

    private fun pause(k: String): Long = when (k) {
        "open_app" -> 2500L; "wait" -> 0L; "tap" -> 900L; "global" -> 700L; "swipe" -> 500L; else -> 300L
    }

    fun runAll(c: Context, acts: List<JSONObject>): List<R> {
        val out = ArrayList<R>()
        var hidden = false
        for (a in acts.take(10)) {
            val k = a.optString("a")
            if (!hidden && MainActivity.visible && needsScreen(a)) { MainActivity.hide(); Thread.sleep(900); hidden = true }
            val r = try { one(c, a) } catch (e: Exception) { R(false, "Не получилось: " + (e.message ?: k)) }
            Phone.invalidateShot() // после любого действия экран меняется — старый кадр больше не годится
            out.add(r)
            if (!r.ok) break
            Thread.sleep(pause(k))
        }
        return out
    }

    private fun one(c: Context, a: JSONObject): R {
        val k = a.optString("a")
        val svc = AlterAccessibilityService.instance
        val noSvc = R(false, "Включите специальные возможности Axel в настройках Android")
        return when (k) {
            "open_app" -> {
                val n = a.optString("name")
                if (Phone.openApp(c, n, a.optString("pkg"))) R(true, "Открываю $n") else R(false, "Не нашёл приложение «$n»")
            }
            "torch" -> {
                val on = tri(a, "on")
                if (Phone.torch(c, on)) R(true, if (on == false) "Выключаю фонарик" else if (on == true) "Включаю фонарик" else "Переключаю фонарик")
                else R(false, "Не получилось управлять фонариком")
            }
            "tile" -> {
                if (svc == null) return noSvc
                val key = a.optString("name")
                val labels = TILES[key] ?: return R(false, "Не знаю переключатель «$key»")
                val on = tri(a, "on")
                val nm = NAMES[key] ?: key
                when (svc.toggleTile(labels, on)) {
                    0 -> R(false, "Не нашёл переключатель «$nm» в шторке быстрых настроек")
                    2 -> R(true, "$nm уже " + (if (on == true) "включён" else "выключен"))
                    else -> R(true, if (on == true) "Включаю $nm" else if (on == false) "Выключаю $nm" else "Переключаю $nm")
                }
            }
            "brightness" -> {
                if (!Settings.System.canWrite(c)) {
                    Phone.start(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.packageName)))
                    return R(false, "Разрешите Axel менять системные настройки и повторите команду")
                }
                val cr = c.contentResolver
                val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255
                val p = if (a.has("percent")) a.optInt("percent") else cur + a.optInt("delta", -20)
                // минимум 1–5% для «выключи всю яркость», максимум 100%
                val v = p.coerceIn(1, 100)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v * 255 / 100)
                R(true, "Яркость $v процентов")
            }
            "volume" -> {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val st = when (a.optString("stream")) { "ring" -> AudioManager.STREAM_RING; "alarm" -> AudioManager.STREAM_ALARM; else -> AudioManager.STREAM_MUSIC }
                val max = am.getStreamMaxVolume(st)
                val cur = am.getStreamVolume(st) * 100 / max
                val p = if (a.has("percent")) a.optInt("percent") else cur + a.optInt("delta", 15)
                val v = p.coerceIn(0, 100)
                am.setStreamVolume(st, (v * max + 50) / 100, 0) // без системной плашки громкости
                R(true, if (v == 0) "Звук выключен" else "Громкость $v процентов")
            }
            "media" -> {
                val code = when (a.optString("cmd")) {
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE; "toggle" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY
                }
                Phone.mediaKey(c, code)
                R(true, when (a.optString("cmd")) { "next" -> "Следующий трек"; "prev" -> "Предыдущий трек"; "pause" -> "Пауза"; else -> "Включаю" })
            }
            "global" -> {
                if (svc == null) return noSvc
                val g = when (a.optString("cmd")) {
                    "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                    "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                    "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                    "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                    "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                    "power" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
                    "screenshot" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT else -1
                    "lock" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else -1
                    else -> -1
                }
                if (g < 0) R(false, "Это действие не поддерживается на вашем телефоне")
                else R(svc.performGlobalAction(g), when (a.optString("cmd")) { "back" -> "Назад"; "home" -> "Домой"; else -> "Готово" })
            }
            "swipe" -> {
                if (svc == null) return noSvc
                val times = a.optInt("times", 1).coerceIn(1, 10)
                val dir = a.optString("dir", "down")
                repeat(times) { svc.swipe(dir, a.optDouble("frac", 0.5).toFloat()); Thread.sleep(650) }
                R(true, "Листаю")
            }
            "scroll_to" -> {
                if (svc == null) return noSvc
                val t = a.optString("text")
                if (Phone.scrollToSync(c, t, a.optString("dir", "down"))) R(true, "Нашёл «$t»") else R(false, "Не нашёл «$t» после семи прокруток")
            }
            "tap" -> {
                if (a.optBoolean("last")) { if (Phone.tapLast()) R(true, "Нажимаю") else R(false, "Я пока ничего не искал на экране") }
                else { val r = Phone.tapSmart(c, a.optString("text")); R(r.first, r.second) }
            }
            "tap_geo" -> {
                // мгновенное математическое нажатие по зоне экрана: середина, верх, низ, края
                if (svc == null) return noSvc
                val (sw, sh) = svc.screenSize()
                val x = (sw * a.optDouble("x", 0.5)).coerceIn(2.0, (sw - 3).toDouble())
                val y = (sh * a.optDouble("y", 0.5)).coerceIn(2.0, (sh - 3).toDouble())
                Phone.lastX = x; Phone.lastY = y; Phone.lastAt = System.currentTimeMillis()
                if (svc.tapAt(x, y)) R(true, "Готово") else R(false, "Не получилось нажать в эту часть экрана")
            }
            "type_text" -> {
                if (svc == null) return noSvc
                if (svc.typeText(a.optString("text"))) R(true, "Ввожу текст") else R(false, "Не нашёл поле ввода")
            }
            "search_in_app" -> {
                val r = Phone.searchInApp(c, a.optString("text"))
                R(r.first, r.second)
            }
            "wait" -> { Thread.sleep(a.optLong("ms", 1000).coerceIn(0L, 8000L)); R(true, "") }
            "timer" -> {
                val sec = if (a.has("seconds")) a.optInt("seconds") else (a.optDouble("minutes", 1.0) * 60).toInt()
                Phone.timer(c, sec.coerceIn(1, 86400)); R(true, "Ставлю таймер")
            }
            "alarm" -> { Phone.alarm(c, a.optInt("hour").coerceIn(0, 23), a.optInt("minute").coerceIn(0, 59)); R(true, "Ставлю будильник") }
            "search" -> { val q = a.optString("q"); Phone.web(c, "https://www.google.com/search?q=" + enc(q)); R(true, "Ищу $q") }
            "yandex" -> { val q = a.optString("q"); Phone.web(c, "https://ya.ru/search/?text=" + enc(q)); R(true, "Ищу $q в Яндексе") }
            "youtube" -> {
                val u = Uri.parse("https://www.youtube.com/results?search_query=" + enc(a.optString("q")))
                val ok = Phone.start(c, Intent(Intent.ACTION_VIEW, u).setPackage("com.google.android.youtube")) || Phone.start(c, Intent(Intent.ACTION_VIEW, u))
                if (ok) R(true, "Ищу на YouTube") else R(false, "Не получилось открыть YouTube")
            }
            "map" -> { Phone.start(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + enc(a.optString("q"))))); R(true, "Открываю карту") }
            "open_url" -> {
                val u = a.optString("url")
                if (u.startsWith("http")) { Phone.web(c, u); R(true, "Открываю сайт") } else R(false, "Неверная ссылка")
            }
            "camera" -> { Phone.start(c, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); R(true, "Открываю камеру") }
            "settings" -> { Phone.settings(c, PAGES[a.optString("page")] ?: "SETTINGS"); R(true, "Открываю настройки") }
            "call" -> { Phone.start(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.optString("number").filter { it.isDigit() || it == '+' }))); R(true, "Открываю набор номера") }
            "sms" -> {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + a.optString("number").filter { it.isDigit() || it == '+' })).putExtra("sms_body", a.optString("text"))
                Phone.start(c, i); R(true, "Открываю сообщение")
            }
            "stop_speech" -> { Speaker.stop(); R(true, "") }
            "mute" -> { val m = tri(a, "on") ?: true; Speaker.setMuted(c, m); R(true, if (m) "Молчу" else "Снова говорю") }
            "self_off" -> {
                c.getSharedPreferences("axel", 0).edit().putBoolean("enabled", false).putBoolean("callmode", false).apply()
                OverlayService.stop(c)
                VoiceService.stop(c); R(true, "Выключаюсь")
            }
            "gen_image" -> genImage(c, a)
            "rates" -> rates(a)
            "weather" -> weather(c, a)
            "wiki" -> wiki(a)
            "time" -> R(true, SimpleDateFormat("HH:mm, EEEE, d MMMM", Locale("ru")).format(Date()), true)
            "battery" -> {
                val b = (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                R(true, "Заряд $b процентов", true)
            }
            else -> R(false, "Не знаю такого действия")
        }
    }

    /** Встроенный словарь ru->en для промптов картинок (по префиксу: «кота» -> кот -> cat). */
    private val RU_EN = mapOf(
        "кот" to "cat", "котик" to "kitten", "кошк" to "cat", "котён" to "kitten", "собак" to "dog", "пёс" to "dog",
        "щенок" to "puppy", "лошад" to "horse", "льв" to "lion", "тигр" to "tiger", "волк" to "wolf", "медвед" to "bear",
        "мишк" to "teddy bear", "лис" to "fox", "заяц" to "rabbit", "зайчик" to "bunny", "кролик" to "rabbit",
        "мыш" to "mouse", "птиц" to "bird", "орёл" to "eagle", "сов" to "owl", "пингвин" to "penguin", "панд" to "panda",
        "коал" to "koala", "акул" to "shark", "дельфин" to "dolphin", "кит" to "whale", "бабочк" to "butterfly",
        "зме" to "snake", "паук" to "spider", "динозавр" to "dinosaur", "дракон" to "dragon", "единорог" to "unicorn",
        "рыцар" to "knight", "корол" to "king", "королев" to "queen", "принцесс" to "princess", "принц" to "prince",
        "воин" to "warrior", "самура" to "samurai", "ниндзя" to "ninja", "волшебник" to "wizard", "маг" to "wizard",
        "ведьм" to "witch", "робот" to "robot", "монстр" to "monster", "скелет" to "skeleton", "зомби" to "zombie",
        "вампир" to "vampire", "привиден" to "ghost", "ангел" to "angel", "демон" to "demon", "замок" to "castle",
        "крепост" to "fortress", "город" to "city", "деревн" to "village", "лес" to "forest", "джунгл" to "jungle",
        "гор" to "mountains", "мор" to "sea", "океан" to "ocean", "озер" to "lake", "рек" to "river",
        "водопад" to "waterfall", "вулкан" to "volcano", "остров" to "island", "пляж" to "beach", "неб" to "sky",
        "звёзд" to "stars", "звезд" to "stars", "лун" to "moon", "солнц" to "sun", "планет" to "planet",
        "космос" to "space", "галактик" to "galaxy", "вселенн" to "universe", "корабл" to "ship", "лодк" to "boat",
        "пират" to "pirate", "машин" to "car", "автомобил" to "car", "мотоцикл" to "motorcycle", "самолёт" to "airplane",
        "самолет" to "airplane", "ракет" to "rocket", "поезд" to "train", "дом" to "house", "дерев" to "tree",
        "цвет" to "flowers", "роз" to "rose", "сад" to "garden", "портрет" to "portrait", "девушк" to "girl",
        "парен" to "young man", "мальчик" to "boy", "девочк" to "little girl", "мужчин" to "man", "женщин" to "woman",
        "ребён" to "child", "ребен" to "child", "человек" to "person", "лиц" to "face", "пейзаж" to "landscape",
        "закат" to "sunset", "рассвет" to "sunrise", "ноч" to "night", "день" to "day", "зим" to "winter",
        "лет" to "summer", "осен" to "autumn", "весн" to "spring", "дожд" to "rain", "снег" to "snow",
        "гроз" to "storm", "молни" to "lightning", "радуг" to "rainbow", "облак" to "clouds", "туч" to "storm clouds",
        "огон" to "fire", "вод" to "water", "меч" to "sword", "щит" to "shield", "мяч" to "ball",
        "футбол" to "football", "баскетбол" to "basketball", "геймер" to "gamer", "игр" to "game",
        "супергерой" to "superhero", "герой" to "hero", "злоде" to "villain"
    )

    /** Перевод промпта: словарь -> ИИ -> чистка кириллицы. Возвращает английскую строку. */
    private fun dictTranslate(q: String): String {
        val words = q.lowercase().split(Regex("[^а-яёa-z0-9]+")).filter { it.isNotBlank() }
        val out = ArrayList<String>()
        for (w in words) {
            if (Regex("^[a-z0-9]+$").containsMatchIn(w)) { out.add(w); continue }
            var hit = ""
            for ((k, v) in RU_EN) if (w.startsWith(k) && k.length > hit.length) hit = v
            if (hit.isNotBlank()) out.add(hit)
        }
        return out.joinToString(" ")
    }

    private fun cleanPrompt(q: String): String =
        q.replace(Regex("[\\u0400-\\u04FF]"), " ").replace(Regex("[^\\w\\s,+.-]"), " ")
            .replace(Regex("\\s+"), " ").trim()

    /** Генерация картинки: перевод на английский (ИИ или словарь) -> ImageGen (OpenRouter -> Gemini -> Pollinations -> AI Horde). */
    private fun genImage(c: Context, a: JSONObject): R {
        val q = a.optString("q")
        if (q.isBlank()) return R(false, "Скажите, что нарисовать")
        Phone.status(c, "Рисую…")
        var en = dictTranslate(q)
        val ai = Phone.ai(c)
        if (ai != null) {
            val better = try {
                Brain.quick(ai, "Translate the user request into English and improve it as a vivid, detailed image-generation prompt (subject, style, lighting). Return ONLY the English prompt, one line, max 60 words.", q, 200)
            } catch (e: Exception) { null }
            val cleaned = better?.let { cleanPrompt(it) }
            if (!cleaned.isNullOrBlank() && cleaned.length > 3) en = cleaned
        }
        val prompt = if (cleanPrompt(en).isNotBlank()) cleanPrompt(en) else "beautiful digital art"
        val out = ImageGen.generate(c, ai, prompt) { msg -> Phone.status(c, msg) }
        val url = out.url
        if (url == null) return R(false, "Не получилось нарисовать: " + (out.err ?: "сервисы картинок не ответили") + ". Попробуйте ещё раз чуть позже.")
        val pr = c.getSharedPreferences("axel", 0)
        val arr = try { org.json.JSONArray(pr.getString("log", "[]")) } catch (e: Exception) { org.json.JSONArray() }
        arr.put(JSONObject().put("img", url).put("say", "🎨"))
        pr.edit().putString("log", arr.toString()).apply()
        MainActivity.inst?.ping()
        return R(true, "Готово, держи 🎨", true)
    }

    private fun rates(a: JSONObject): R {
        val j = Net.get("https://www.cbr-xml-daily.ru/daily_json.js") ?: return R(false, "Не получилось загрузить курс. Проверьте интернет")
        val v = JSONObject(j).getJSONObject("Valute")
        val names = mapOf("USD" to "Доллар", "EUR" to "Евро", "CNY" to "Юань", "GBP" to "Фунт", "KZT" to "Тенге", "UAH" to "Гривна",
            "JPY" to "Иена", "TRY" to "Лира", "PLN" to "Злотый", "BYN" to "Белорусский рубль", "CHF" to "Франк")
        val want = a.optString("cur", "USD,EUR,CNY").uppercase().split(Regex("[,; ]+")).filter { it.isNotBlank() }.take(4)
        val parts = ArrayList<String>()
        for (code in want) {
            val o = v.optJSONObject(code) ?: continue
            val x = o.getDouble("Value") / o.getInt("Nominal")
            parts.add((names[code] ?: code) + " " + String.format(Locale("ru"), "%.2f", x) + " руб.")
        }
        if (parts.isEmpty()) return R(false, "Не нашёл такую валюту")
        return R(true, parts.joinToString(", ") + " по курсу Центробанка", true)
    }

    private fun wmo(c: Int) = when (c) {
        0 -> "ясно"; 1, 2 -> "переменная облачность"; 3 -> "пасмурно"; 45, 48 -> "туман"
        in 51..57 -> "морось"; in 61..67 -> "дождь"; in 71..77 -> "снег"; in 80..82 -> "ливень"; 85, 86 -> "снегопад"
        in 95..99 -> "гроза"; else -> "без осадков"
    }

    private fun sg(x: Double): String { val r = Math.round(x).toInt(); return if (r > 0) "+$r" else "$r" }

    private fun weather(c: Context, a: JSONObject): R {
        val city = a.optString("city").ifBlank { c.getSharedPreferences("axel", 0).getString("city", "") ?: "" }
        if (city.isBlank()) return R(false, "Скажите, для какого города нужна погода")
        val g = Net.get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&name=" + enc(city)) ?: return R(false, "Не получилось загрузить погоду")
        val res = JSONObject(g).optJSONArray("results")?.optJSONObject(0) ?: return R(false, "Не нашёл город «$city»")
        val w = Net.get("https://api.open-meteo.com/v1/forecast?latitude=" + res.getDouble("latitude") + "&longitude=" + res.getDouble("longitude") +
            "&current=temperature_2m,apparent_temperature,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1")
            ?: return R(false, "Не получилось загрузить погоду")
        val j = JSONObject(w)
        val cur = j.getJSONObject("current")
        val d = j.getJSONObject("daily")
        return R(true, res.optString("name", city) + ": сейчас " + sg(cur.getDouble("temperature_2m")) + ", ощущается как " + sg(cur.getDouble("apparent_temperature")) +
            ", " + wmo(cur.getInt("weather_code")) + ", ветер " + Math.round(cur.getDouble("wind_speed_10m") / 3.6) + " метров в секунду. Днём до " +
            sg(d.getJSONArray("temperature_2m_max").getDouble(0)) + ", ночью до " + sg(d.getJSONArray("temperature_2m_min").getDouble(0)), true)
    }

    private fun wiki(a: JSONObject): R {
        val q = a.optString("q")
        val j = Net.get("https://ru.wikipedia.org/w/api.php?action=query&format=json&generator=search&gsrlimit=1&prop=extracts&exintro=1&explaintext=1&exsentences=3&redirects=1&gsrsearch=" + enc(q))
            ?: return R(false, "Не получилось загрузить справку")
        val pages = JSONObject(j).optJSONObject("query")?.optJSONObject("pages") ?: return R(false, "Ничего не нашёл про «$q»")
        val first = pages.keys().asSequence().firstOrNull() ?: return R(false, "Ничего не нашёл про «$q»")
        val ex = pages.getJSONObject(first).optString("extract").replace(Regex("\\([^)]*\\)"), "").replace(Regex("\\s+"), " ").trim().take(450)
        return if (ex.isBlank()) R(false, "Ничего не нашёл про «$q»") else R(true, ex, true)
    }
}
