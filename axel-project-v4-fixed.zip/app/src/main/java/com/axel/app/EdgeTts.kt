package com.axel.app

import android.content.Context
import android.media.MediaPlayer
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Бесплатный нейроголос ru-RU-DmitryNeural через Edge TTS (websocket Microsoft, без ключа).
 *  Глубокий мужской тембр: pitch -8%, rate +5%. При любой ошибке Axel откатывается к встроенному TTS. */
object EdgeTts {
    private const val TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private const val VOICE = "ru-RU-DmitryNeural"
    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    @Volatile private var cancelRef: WebSocket? = null

    /** Sec-MS-GEC: sha256(ticks + token) в верхнем регистре, ticks кратно 5 минутам в 100-нс единицах Windows. */
    private fun gec(): String {
        val sec = System.currentTimeMillis() / 1000 + 11644473600L
        val ticks = (sec - sec % 300) * 10000000L
        val digest = MessageDigest.getInstance("SHA-256").digest((ticks.toString() + TOKEN).toByteArray())
        return digest.joinToString("") { "%02X".format(it) }
    }

    private fun utc(): String = java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", java.util.Locale.US)
        .also { it.timeZone = java.util.TimeZone.getTimeZone("GMT") }.format(java.util.Date())

    private fun hex32(): String = (0 until 32).map { "0123456789abcdef"[(Math.random() * 16).toInt()] }.joinToString("")

    /** Асинхронный синтез: mp3 во временный файл -> MediaPlayer. done вызывается ровно один раз.
     *  Возвращает true, если соединение запущено; false — сразу откатиться на встроенный TTS. */
    fun synthesize(c: Context, text: String, done: () -> Unit): Boolean {
        val finished = AtomicBoolean(false)
        val fin = { if (finished.compareAndSet(false, true)) done() }
        return try {
            val cid = hex32()
            val url = "wss://api.msedgeservices.com/tts/cognitiveservices/websocket/v1" +
                "?TrustedClientToken=" + TOKEN + "&Sec-MS-GEC=" + gec() +
                "&Sec-MS-GEC-Version=1-131.0.2903.112&ConnectionId=" + cid
            val audioBytes = ByteArrayOutputStream()
            val esc = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            val ssml = "<speak version=\"1.0\" xmlns=\"http://www.w3.org/2001/10/synthesis\" xml:lang=\"ru-RU\">" +
                "<voice name=\"" + VOICE + "\"><prosody rate=\"+5.00%\" pitch=\"-8.00%\">" + esc + "</prosody></voice></speak>"
            val ws = client.newWebSocket(
                Request.Builder().url(url)
                    .header("Origin", "https://azure.microsoft.com")
                    .header("User-Agent", "Mozilla/5.0")
                    .build(),
                object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        try {
                            webSocket.send("X-Timestamp:" + utc() + "\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n" +
                                JSONObject().put("context", JSONObject().put("synthesis", JSONObject().put("audio",
                                    JSONObject().put("metadataoptions", JSONObject()
                                        .put("sentenceBoundaryEnabled", "false")
                                        .put("wordBoundaryEnabled", "false"))
                                        .put("outputFormat", "audio-24khz-48kbitrate-mono-mp3")))).toString())
                            webSocket.send("X-RequestId:" + cid + "\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:" + utc() + "Z\r\nPath:ssml\r\n\r\n" + ssml)
                        } catch (e: Exception) { fin() }
                    }

                    override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                        try {
                            val b = bytes.toByteArray()
                            val hl = ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
                            if (b.size > 2 + hl) audioBytes.write(b, 2 + hl, b.size - 2 - hl)
                        } catch (e: Exception) { }
                    }

                    override fun onMessage(webSocket: WebSocket, msg: String) {
                        if (msg.contains("Path:turn.end")) {
                            try { webSocket.close(1000, null) } catch (e: Exception) { }
                            val bytes = audioBytes.toByteArray()
                            if (bytes.isEmpty()) { fin(); return }
                            try {
                                val f = File.createTempFile("axel_tts_", ".mp3", c.cacheDir)
                                f.writeBytes(bytes)
                                val mp = MediaPlayer()
                                mp.setDataSource(f.absolutePath)
                                mp.setOnCompletionListener {
                                    try { mp.release() } catch (e: Exception) { }
                                    f.delete(); fin()
                                }
                                mp.setOnErrorListener { _, _, _ ->
                                    try { mp.release() } catch (e: Exception) { }
                                    f.delete(); fin(); true
                                }
                                mp.prepare()
                                mp.start()
                            } catch (e: Exception) { fin() }
                        }
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { fin() }
                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { }
                }
            )
            cancelRef = ws
            true
        } catch (e: Exception) { fin(); false }
    }

    fun cancel() { try { cancelRef?.close(1000, null) } catch (e: Exception) { }; cancelRef = null }
}
